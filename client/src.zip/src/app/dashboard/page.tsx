"use client";

import AuthGuard from "@/components/auth/AuthGuard";
import Navbar from "@/components/layout/Navbar";

import DashboardHeader from "@/components/dashboard/DashboardHeader";
import ATSScoreCard from "@/components/dashboard/ATSScoreCard";
import SummaryCard from "@/components/dashboard/SummaryCard";
import SkillsCard from "@/components/dashboard/SkillsCard";
import StrengthsCard from "@/components/dashboard/StrengthsCard";
import MissingSkillsCard from "@/components/dashboard/MissingSkillsCard";
import SuggestionsCard from "@/components/dashboard/SuggestionsCard";
import ATSBarChart from "@/components/dashboard/charts/ATSBarChart";
import SkillsChart from "@/components/dashboard/charts/SkillsChart";

import { useResumeStore } from "@/store/resume.store";

export default function DashboardPage() {

  const { analysis } =
    useResumeStore();

  if (!analysis) {
    return (
      <AuthGuard>
        <Navbar />

        <div className="flex min-h-[80vh] items-center justify-center text-2xl font-semibold">
          No Resume Analysis Found
        </div>

      </AuthGuard>
    );
  }

  return (
    <AuthGuard>

      <Navbar />

      <main className="mx-auto max-w-7xl space-y-8 px-6 py-10">

        <DashboardHeader />

        <div className="grid gap-8 lg:grid-cols-2">

          <ATSScoreCard
            score={analysis.atsScore}
          />

          <SummaryCard
            summary={analysis.summary}
          />

        </div>

        <SkillsCard
          skills={analysis.skills}
        />

        <div className="grid gap-8 lg:grid-cols-2">

          <StrengthsCard
            strengths={analysis.strengths}
          />

          <MissingSkillsCard
            skills={analysis.missingSkills}
          />

        </div>

        <SuggestionsCard
          suggestions={analysis.suggestions}
        />
        <div className="grid gap-8 lg:grid-cols-2">

          <ATSBarChart
            score={analysis.atsScore}
          />

          <SkillsChart
            skills={analysis.skills}
          />

        </div>

      </main>

    </AuthGuard>
  );
}