"use client";

import AuthGuard from "@/components/auth/AuthGuard";
import Navbar from "@/components/layout/Navbar";

import JobMatchCard from "@/components/dashboard/JobMatchCard";
import MissingSkillsCard from "@/components/dashboard/MissingSkillsCard";

import { useJobStore } from "@/store/job.store";

export default function JobResultPage() {

  const { result } = useJobStore();

  if (!result) {
    return (
      <AuthGuard>
        <Navbar />

        <div className="flex min-h-screen items-center justify-center text-2xl">
          No Job Analysis Found
        </div>

      </AuthGuard>
    );
  }

  return (
    <AuthGuard>

      <Navbar />

      <main className="mx-auto max-w-6xl space-y-8 px-6 py-10">

        <h1 className="text-5xl font-black">
          AI Job Match Result
        </h1>

        <JobMatchCard
          score={result.matchScore}
        />

        <MissingSkillsCard
          skills={result.missingSkills}
        />

        <div className="rounded-3xl border bg-white p-8 shadow">

          <h2 className="mb-4 text-2xl font-bold">
            Recommendation
          </h2>

          <p>
            {result.recommendation}
          </p>

        </div>

        <div className="rounded-3xl border bg-white p-8 shadow">

          <h2 className="mb-4 text-2xl font-bold">
            Interview Readiness
          </h2>

          <div className="text-7xl font-black text-green-600">

            {result.interviewReadiness}/10

          </div>

        </div>

      </main>

    </AuthGuard>
  );
}