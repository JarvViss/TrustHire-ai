"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";

import Navbar from "@/components/layout/Navbar";
import RecruiterGuard from "@/components/auth/RecruiterGuard";

import CandidateProfile from "@/components/recruiter/CandidateProfile";

import api from "@/lib/axios";

export default function CandidatePage() {
  const { id } = useParams();

  const [candidate, setCandidate] =
    useState<any>(null);

  const [loading, setLoading] =
    useState(true);

  useEffect(() => {
    async function load() {
      try {
        const res = await api.get(
          `/recruiter/candidate/${id}`
        );

        console.log(res.data);

        setCandidate(
          res.data.candidate
        );
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }

    if (id) {
      load();
    }
  }, [id]);

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center text-xl">
        Loading Candidate...
      </div>
    );
  }

  if (!candidate) {
    return (
      <div className="flex h-screen items-center justify-center text-xl">
        Candidate not found.
      </div>
    );
  }

  return (
    <RecruiterGuard>
      <Navbar />

      <main className="mx-auto max-w-7xl p-8">
        <CandidateProfile
          candidate={candidate}
        />
      </main>
    </RecruiterGuard>
  );
}