interface Props {
  score: number;
}

export default function JobMatchCard({
  score,
}: Props) {
  return (
    <div className="rounded-3xl border bg-white p-8 shadow">
      <h2 className="mb-5 text-2xl font-bold">
        Job Match Score
      </h2>

      <div className="text-7xl font-black text-indigo-600">
        {score}%
      </div>
    </div>
  );
}