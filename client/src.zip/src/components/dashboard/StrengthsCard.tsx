import { CheckCircle2 } from "lucide-react";

import DashboardCard from "./DashboardCard";

interface Props {
  strengths: string[];
}

export default function StrengthsCard({
  strengths,
}: Props) {
  return (
    <DashboardCard title="Strengths">

      <div className="space-y-4">

        {strengths?.length ? (
          strengths.map((strength) => (
            <div
              key={strength}
              className="flex items-center gap-3 rounded-2xl bg-green-50 p-4"
            >
              <CheckCircle2
                className="text-green-600"
                size={22}
              />

              <span>{strength}</span>

            </div>
          ))
        ) : (
          <p>No strengths found.</p>
        )}

      </div>

    </DashboardCard>
  );
}