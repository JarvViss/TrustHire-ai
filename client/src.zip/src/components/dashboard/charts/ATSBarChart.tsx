"use client";

import {
  BarChart,
  Bar,
  XAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

interface Props {
  score: number;
}

export default function ATSBarChart({
  score,
}: Props) {
  const data = [
    {
      name: "ATS",
      value: score,
    },
  ];

  return (
    <div className="rounded-3xl border bg-white p-8 shadow-sm">

      <h2 className="mb-6 text-2xl font-bold">
        ATS Breakdown
      </h2>

      <div className="h-80">

        <ResponsiveContainer>

          <BarChart data={data}>

            <XAxis dataKey="name" />

            <Tooltip />

            <Bar
              dataKey="value"
              radius={[12, 12, 0, 0]}
            >
              <Cell
                fill={
                  score >= 85
                    ? "#22c55e"
                    : score >= 70
                    ? "#f59e0b"
                    : "#ef4444"
                }
              />
            </Bar>

          </BarChart>

        </ResponsiveContainer>

      </div>

    </div>
  );
}