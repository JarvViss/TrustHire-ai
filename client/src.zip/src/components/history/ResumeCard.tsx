"use client";

import { Button } from "@/components/ui/button";

interface Props {
  resume: any;

  onView: () => void;

  onDelete: () => void;
}

export default function ResumeCard({
  resume,
  onView,
  onDelete,
}: Props) {
  return (
    <div className="rounded-3xl border bg-white p-6 shadow">

      <h2 className="text-xl font-bold">
        {resume.filename}
      </h2>

      <p className="mt-2">
        ATS Score:
        <span className="font-bold text-blue-600">
          {" "}
          {resume.atsScore}
        </span>
      </p>

      <p className="mt-2 text-slate-500">
        {new Date(
          resume.createdAt
        ).toLocaleString()}
      </p>

      <div className="mt-6 flex gap-4">

        <Button
          variant="outline"
          onClick={onView}
        >
          View
        </Button>

        <Button
          variant="destructive"
          onClick={onDelete}
        >
          Delete
        </Button>

      </div>

    </div>
  );
}