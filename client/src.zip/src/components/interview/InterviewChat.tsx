"use client";

import { useState } from "react";

import { Button } from "@/components/ui/button";

import InterviewProgress from "./InterviewProgress";
import Thinking from "./Thinking";

import { useSubmitAnswer } from "@/hooks/useInterview";

interface Props {
  interview: any;
  setInterview: (value: any) => void;
}

export default function InterviewChat({
  interview,
  setInterview,
}: Props) {
  const mutation = useSubmitAnswer();

  const [answer, setAnswer] = useState("");

  const handleSubmit = async () => {
    if (!answer.trim()) return;

    try {
      const result =
        await mutation.mutateAsync({
          interviewId: interview._id,
          answer,
        });

        console.log(result.data);

      setInterview(result.data);

      setAnswer("");
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div>

      <InterviewProgress
        current={interview.currentQuestion + 1}
        total={5}
      />

      <div className="space-y-6">

        {interview.conversation.map(
          (item: any, index: number) => (
            <div key={index}>

              <div className="rounded-2xl bg-blue-600 p-5 text-white">

                <strong>
                  AI Interviewer
                </strong>

                <p className="mt-2">
                  {item.question}
                </p>

              </div>

              {item.answer && (
                <div className="mt-3 ml-auto max-w-3xl rounded-2xl bg-slate-100 p-5">

                  <strong>You</strong>

                  <p className="mt-2">
                    {item.answer}
                  </p>

                </div>
              )}

            </div>
          )
        )}

        {mutation.isPending && (
          <Thinking />
        )}

        {!interview.completed && (
          <>

            <textarea
              rows={6}
              value={answer}
              onChange={(e) =>
                setAnswer(e.target.value)
              }
              placeholder="Write your answer here..."
              className="w-full rounded-2xl border p-5"
            />

            <Button
              className="w-full"
              disabled={mutation.isPending}
              onClick={handleSubmit}
            >
              Submit Answer
            </Button>

          </>
        )}

      </div>

    </div>
  );
}