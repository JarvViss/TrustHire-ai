"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";

import { Button } from "@/components/ui/button";

import { useAuthStore } from "@/store/auth.store";
import { useResumeStore } from "@/store/resume.store";

export default function Navbar() {
  const router = useRouter();

  const logout = useAuthStore((state) => state.logout);

  const clear = useResumeStore((state) => state.clear);

  const handleLogout = () => {
    logout();

    clear();

    router.push("/login");
  };

  return (
    <nav className="border-b bg-white shadow-sm">

      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">

        <Link
          href="/dashboard"
          className="text-2xl font-black text-blue-600"
        >
          TrustHire AI
        </Link>

        <div className="flex items-center gap-3">

          <Link href="/dashboard">
            <Button variant="outline">
              Dashboard
            </Button>
          </Link>

          <Link href="/upload">
            <Button variant="outline">
              Upload Resume
            </Button>
          </Link>

          <Link href="/history">
            <Button variant="outline">
              Resume History
            </Button>
          </Link>

          <Link href="/job-match">
            <Button variant="outline">
              AI Job Match
            </Button>
          </Link>
          <Link href="/interview">
            <Button variant="outline">
              AI Interview
            </Button>
          </Link>
          <Button
            variant="outline"
            onClick={handleLogout}
          >
            Logout
          </Button>

        </div>

      </div>

    </nav>
  );
}