interface Props {
  user: any;
}

export default function CandidateHeader({
  user,
}: Props) {
  return (
    <div className="rounded-3xl border bg-white p-8 shadow">

      <div className="flex flex-col justify-between gap-8 lg:flex-row">

        <div>

          <div className="flex items-center gap-5">

            <div className="flex h-24 w-24 items-center justify-center rounded-full bg-blue-600 text-4xl font-bold text-white">
              {user?.name?.charAt(0)}
            </div>

            <div>

              <h1 className="text-4xl font-black">
                {user?.name}
              </h1>

              <p className="mt-2 text-lg text-slate-500">
                {user?.headline}
              </p>

              <p className="mt-1 text-slate-400">
                {user?.location}
              </p>

            </div>

          </div>

        </div>

        <div className="space-y-3">

          <a href={user?.github} target="_blank">
            Github
          </a>

          <br />

          <a href={user?.linkedin} target="_blank">
            LinkedIn
          </a>

          <br />

          <a href={user?.portfolio} target="_blank">
            Portfolio
          </a>

        </div>

      </div>

    </div>
  );
}