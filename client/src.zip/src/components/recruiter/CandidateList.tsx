"use client";

import Link from "next/link";

interface Candidate {
  id: string;
  name: string;
  email: string;
  headline: string;
  atsScore: number;
  interviewScore: number;
  jobMatch: number;
  recommendation: string;
  verified: boolean;
}

interface Props {
  candidates: Candidate[];
}

export default function CandidateList({
  candidates,
}: Props) {
  if (!candidates.length) {
    return (
      <div className="rounded-3xl border bg-white p-12 text-center shadow">
        <h2 className="text-2xl font-bold">
          No Candidates Yet
        </h2>

        <p className="mt-2 text-slate-500">
          Candidates will appear here after uploading resumes.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {candidates.map((candidate) => (
        <Link
          key={candidate.id}
          href={`/recruiter/candidate/${candidate.id}`}
        >
          <div className="cursor-pointer rounded-3xl border border-slate-200 bg-white p-8 shadow-sm transition-all hover:-translate-y-1 hover:shadow-xl">
            <div className="flex flex-col justify-between gap-6 lg:flex-row">
              <div>
                <h2 className="text-2xl font-bold">
                  {candidate.name}
                </h2>

                <p className="text-slate-500">
                  {candidate.email}
                </p>

                <p className="mt-2 font-medium text-blue-600">
                  {candidate.headline || "No headline"}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-6 text-center md:grid-cols-4">
                <Score
                  title="ATS"
                  value={`${candidate.atsScore}%`}
                />

                <Score
                  title="Interview"
                  value={candidate.interviewScore}
                />

                <Score
                  title="Job Match"
                  value={`${candidate.jobMatch}%`}
                />

                <Score
                  title="Status"
                  value={candidate.recommendation}
                />
              </div>
            </div>

            <div className="mt-6 flex items-center gap-3">
              {candidate.verified && (
                <span className="rounded-full bg-green-100 px-4 py-2 text-sm font-semibold text-green-700">
                  Blockchain Verified
                </span>
              )}
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}

function Score({
  title,
  value,
}: {
  title: string;
  value: string | number;
}) {
  return (
    <div>
      <p className="text-sm text-slate-500">
        {title}
      </p>

      <p className="mt-2 text-xl font-bold text-blue-600">
        {value}
      </p>
    </div>
  );
}