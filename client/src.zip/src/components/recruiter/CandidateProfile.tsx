import CandidateHeader from "./CandidateHeader";
import CandidateScores from "./CandidateScores";
import ResumeSummaryCard from "./ResumeSummaryCard";
import SkillsCard from "./SkillsCard";
import InterviewReportCard from "./InterviewReportCard";
import VerificationCard from "./VerificationCard";
import RecruiterActions from "./RecruiterActions";

interface Props {
  candidate: any;
}

// export default function CandidateProfile({
//   candidate,
// }: Props) {
//   return (
//     <div className="space-y-8">

//       <CandidateHeader
//         user={candidate.user}
//       />

//       <CandidateScores
//         resume={candidate.resume}
//         interview={candidate.interview}
//         analysis={candidate.analysis}
//       />

//       <ResumeSummaryCard
//         summary={candidate.resume?.summary}
//       />

//       <SkillsCard
//         skills={candidate.resume?.skills ?? []}
//         missingSkills={
//           candidate.resume?.missingSkills ?? []
//         }
//       />

//       <InterviewReportCard
//         result={candidate.interview?.result}
//       />

//       <VerificationCard
//         user={candidate.user}
//       />

//       <RecruiterActions
//     candidate={candidate}
// />
      

//     </div>
//   );
// }

export default function CandidateProfile({ candidate }: Props) {
  return (
    <div className="min-h-screen bg-red-500 text-white text-5xl flex items-center justify-center">
      THIS IS THE NEW CANDIDATE PROFILE
    </div>
  );
}