interface Props {
  resume: any;
  interview: any;
  analysis: any;
}

export default function CandidateScores({
  resume,
  interview,
  analysis,
}: Props) {
  return (
    <div className="grid gap-6 md:grid-cols-4">

      <Card
        title="ATS"
        value={`${resume?.atsScore ?? 0}%`}
      />

      <Card
        title="Interview"
        value={
          interview?.result?.overall ?? 0
        }
      />

      <Card
        title="Job Match"
        value={`${analysis?.matchScore ?? 0}%`}
      />

      <Card
        title="Recommendation"
        value={
          interview?.result
            ?.recommendation ??
          "-"
        }
      />

    </div>
  );
}

function Card({
  title,
  value,
}: any) {
  return (
    <div className="rounded-3xl border bg-white p-8 text-center shadow">

      <p className="text-slate-500">
        {title}
      </p>

      <h2 className="mt-3 text-4xl font-black text-blue-600">
        {value}
      </h2>

    </div>
  );
}