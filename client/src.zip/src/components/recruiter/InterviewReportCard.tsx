interface Props {
  result: any;
}

export default function InterviewReportCard({
  result,
}: Props) {
  if (!result)
    return null;

  return (
    <div className="rounded-3xl border bg-white p-8 shadow">

      <h2 className="mb-8 text-3xl font-bold">
        Interview Report
      </h2>

      <div className="grid gap-5 md:grid-cols-4">

        <Score
          title="Overall"
          value={result.overall}
        />

        <Score
          title="Technical"
          value={result.technical}
        />

        <Score
          title="Communication"
          value={result.communication}
        />

        <Score
          title="Confidence"
          value={result.confidence}
        />

      </div>

    </div>
  );
}

function Score({
  title,
  value,
}: any) {
  return (
    <div className="rounded-2xl border p-6 text-center">

      <p>{title}</p>

      <h2 className="mt-2 text-4xl font-black text-blue-600">
        {value}
      </h2>

    </div>
  );
}