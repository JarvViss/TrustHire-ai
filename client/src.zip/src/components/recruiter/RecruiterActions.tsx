"use client";

import { useState } from "react";

import api from "@/lib/axios";

interface Props {
  candidate: any;
}

export default function RecruiterActions({
  candidate,
}: Props) {
  const [notes, setNotes] = useState("");

  const [loading, setLoading] =
    useState(false);

  async function updateStatus(
    status:
      | "HIRED"
      | "SHORTLISTED"
      | "REJECTED"
  ) {
    try {
      setLoading(true);

      await api.post(
        "/recruiter-action/candidate/action",
        {
          candidateId:
            candidate.user._id,
          status,
          notes,
        }
      );

      alert(
        `Candidate ${status.toLowerCase()} successfully`
      );
    } catch {
      alert(
        "Something went wrong."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="rounded-3xl border bg-white p-8 shadow">

      <h2 className="mb-6 text-2xl font-bold">
        Recruiter Decision
      </h2>

      <textarea
        rows={5}
        value={notes}
        onChange={(e) =>
          setNotes(e.target.value)
        }
        placeholder="Recruiter Notes..."
        className="w-full rounded-xl border p-4 outline-none"
      />

      <div className="mt-8 flex flex-wrap gap-4">

        <button
          disabled={loading}
          onClick={() =>
            updateStatus("HIRED")
          }
          className="rounded-xl bg-green-600 px-6 py-3 font-semibold text-white"
        >
          Hire
        </button>

        <button
          disabled={loading}
          onClick={() =>
            updateStatus(
              "SHORTLISTED"
            )
          }
          className="rounded-xl bg-blue-600 px-6 py-3 font-semibold text-white"
        >
          Shortlist
        </button>

        <button
          disabled={loading}
          onClick={() =>
            updateStatus(
              "REJECTED"
            )
          }
          className="rounded-xl bg-red-600 px-6 py-3 font-semibold text-white"
        >
          Reject
        </button>

      </div>

    </div>
  );
}