interface Props {
  stats: {
    totalCandidates: number;
    totalResumes: number;
    completedInterviews: number;
    verifiedCandidates: number;
  };
}

export default function RecruiterStats({
  stats,
}: Props) {
  const cards = [
    {
      title: "Candidates",
      value: stats.totalCandidates,
    },
    {
      title: "Resumes",
      value: stats.totalResumes,
    },
    {
      title: "Completed Interviews",
      value: stats.completedInterviews,
    },
    {
      title: "Verified",
      value: stats.verifiedCandidates,
    },
  ];

  return (
    <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
      {cards.map((card) => (
        <div
          key={card.title}
          className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm transition-all hover:-translate-y-1 hover:shadow-xl"
        >
          <p className="text-sm font-medium uppercase tracking-wide text-slate-500">
            {card.title}
          </p>

          <h2 className="mt-4 text-5xl font-black text-blue-600">
            {card.value}
          </h2>
        </div>
      ))}
    </div>
  );
}