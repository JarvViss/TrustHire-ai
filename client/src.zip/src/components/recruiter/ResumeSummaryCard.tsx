interface Props {
  summary: string;
}

export default function ResumeSummaryCard({
  summary,
}: Props) {
  return (
    <div className="rounded-3xl border bg-white p-8 shadow">

      <h2 className="mb-6 text-2xl font-bold">
        Resume Summary
      </h2>

      <p className="leading-8">
        {summary}
      </p>

    </div>
  );
}