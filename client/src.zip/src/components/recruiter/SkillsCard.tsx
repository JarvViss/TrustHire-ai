interface Props {
  skills: string[];
  missingSkills: string[];
}

export default function SkillsCard({
  skills,
  missingSkills,
}: Props) {
  return (
    <div className="grid gap-8 lg:grid-cols-2">

      <div className="rounded-3xl border bg-white p-8 shadow">

        <h2 className="mb-5 text-2xl font-bold">
          Skills
        </h2>

        <div className="flex flex-wrap gap-3">

          {skills.map((skill) => (
            <span
              key={skill}
              className="rounded-full bg-blue-100 px-4 py-2 text-blue-700"
            >
              {skill}
            </span>
          ))}

        </div>

      </div>

      <div className="rounded-3xl border bg-white p-8 shadow">

        <h2 className="mb-5 text-2xl font-bold">
          Missing Skills
        </h2>

        <div className="flex flex-wrap gap-3">

          {missingSkills.map((skill) => (
            <span
              key={skill}
              className="rounded-full bg-red-100 px-4 py-2 text-red-700"
            >
              {skill}
            </span>
          ))}

        </div>

      </div>

    </div>
  );
}