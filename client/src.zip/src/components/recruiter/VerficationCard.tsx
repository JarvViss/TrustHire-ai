interface Props {
  user: any;
}

export default function VerificationCard({
  user,
}: Props) {
  return (
    <div className="rounded-3xl border bg-white p-8 shadow">

      <h2 className="mb-6 text-2xl font-bold">
        Blockchain Verification
      </h2>

      <p>

        Status :

        {user?.isVerified ? (
          <span className="ml-2 font-bold text-green-600">
            VERIFIED
          </span>
        ) : (
          <span className="ml-2 font-bold text-red-600">
            NOT VERIFIED
          </span>
        )}

      </p>

      <p className="mt-5 break-all">

        Wallet :

        {user?.walletAddress || "-"}

      </p>

    </div>
  );
}