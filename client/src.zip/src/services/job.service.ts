import api from "@/lib/api";

export const analyzeJob = async (
  jobDescription: string
) => {
  const { data } = await api.post(
    "/job/analyze",
    {
      jobDescription,
    }
  );

  return data;
};