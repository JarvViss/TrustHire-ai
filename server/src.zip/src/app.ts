import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import cookieParser from "cookie-parser";

import routes from "./routes";
import { errorHandler } from "./middleware/error.middleware";

const app = express();

/* ---------- Global Middlewares ---------- */

app.use(cors());

app.use(express.json());

app.use(express.urlencoded({ extended: true }));

app.use(cookieParser());

app.use(helmet());

app.use(morgan("dev"));

/* ---------- Health Check ---------- */

app.get("/", (req, res) => {
  res.json({
    message: "TrustHire AI API Running 🚀",
  });
});

/* ---------- API Routes ---------- */

app.use("/api", routes);

/* ---------- Error Handler ---------- */

app.use(errorHandler);

export default app;