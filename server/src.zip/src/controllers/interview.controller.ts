import { Response } from "express";

import { AuthRequest } from "../middleware/auth.middleware";

import Interview from "../models/Interview";

import {
  startInterview,
  submitAnswer,
} from "../services/interview.service";

export async function createInterview(
  req: AuthRequest,
  res: Response
) {
  try {
    const { role } = req.body;

    if (!role) {
      return res.status(400).json({
        success: false,
        message: "Role is required",
      });
    }

    const interview = await startInterview(
      req.userId!,
      role
    );

    return res.status(201).json({
      success: true,
      data: interview,
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message: "Failed to start interview",
    });
  }
}

export async function answerInterview(
  req: AuthRequest,
  res: Response
) {
  try {
    const { interviewId, answer } = req.body;

    const interview =
      await submitAnswer(
        interviewId,
        answer
      );

    return res.json({
      success: true,
      data: interview,
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message: "Interview failed",
    });
  }
}

export async function getInterview(
  req: AuthRequest,
  res: Response
) {
  try {
    const interview = await Interview.findOne({
      _id: req.params.id,
      user: req.userId,
    });

    if (!interview) {
      return res.status(404).json({
        success: false,
        message: "Interview not found",
      });
    }

    return res.json({
      success: true,
      data: interview,
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message:
        "Failed to fetch interview",
    });
  }
}