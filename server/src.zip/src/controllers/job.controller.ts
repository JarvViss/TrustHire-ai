import { Response } from "express";

import Resume from "../models/Resume";

import { analyzeJobMatch } from "../services/ai.service";

import { AuthRequest } from "../middleware/auth.middleware";

export const analyzeJob = async (
  req: AuthRequest,
  res: Response
) => {
  try {
    const { jobDescription } = req.body;

    if (!jobDescription) {
      return res.status(400).json({
        success: false,
        message: "Job Description is required",
      });
    }

    if (jobDescription.trim().length < 100) {
      return res.status(400).json({
        success: false,
        message:
          "Please paste a complete Job Description (minimum 100 characters).",
      });
    }

    const resume = await Resume.findOne({
      user: req.userId,
    });

    if (!resume) {
      return res.status(404).json({
        success: false,
        message: "Resume not found",
      });
    }

    const result = await analyzeJobMatch(
      resume.summary,
      resume.skills,
      jobDescription
    );

    return res.status(200).json({
      success: true,
      data: result,
    });

  } catch (error) {

    console.error(error);

    return res.status(500).json({
      success: false,
      message: "Job Match Analysis Failed",
    });

  }
};