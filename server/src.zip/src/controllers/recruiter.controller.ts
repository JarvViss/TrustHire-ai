import { Response } from "express";

import { AuthRequest } from "../middleware/auth.middleware";

import {
  dashboardStats,
  candidateList,
  getCandidateProfile,
} from "../services/recruiter.service";

export async function getDashboardStats(
  req: AuthRequest,
  res: Response
) {
  try {
    const stats = await dashboardStats();

    return res.json({
      success: true,
      stats,
    });
  } catch {
    return res.status(500).json({
      success: false,
      message: "Failed to load dashboard",
    });
  }
}

export async function getCandidates(
  req: AuthRequest,
  res: Response
) {
  try {
    const candidates = await candidateList();

    return res.json({
      success: true,
      candidates,
    });
  } catch {
    return res.status(500).json({
      success: false,
      message: "Failed to fetch candidates",
    });
  }
}

export async function getCandidateById(
  req: AuthRequest,
  res: Response
) {
  try {
    const candidate =
      await getCandidateProfile(
        req.params.id as string
      );

    return res.json({
      success: true,
      candidate,
    });
  } catch (err: any) {
    return res.status(404).json({
      success: false,
      message:
        err.message ||
        "Candidate not found",
    });
  }
}