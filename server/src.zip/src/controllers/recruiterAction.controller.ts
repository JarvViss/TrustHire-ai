import { Response } from "express";

import { AuthRequest } from "../middleware/auth.middleware";

import { updateCandidateStatus } from "../services/recruiterAction.service";

export async function recruiterAction(
  req: AuthRequest,
  res: Response
) {
  try {
    const { candidateId, status, notes } =
      req.body;

    const data =
      await updateCandidateStatus(
        req.userId!,
        candidateId,
        status,
        notes
      );

    res.json({
      success: true,
      data,
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      message: err.message,
    });
  }
}