import { Response } from "express";

import Resume from "../models/Resume";

import { AuthRequest } from "../middleware/auth.middleware";

import { processResume } from "../services/resume.service";

export const uploadResume = async (
  req: AuthRequest,
  res: Response
) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "Resume required",
      });
    }

    const resume = await processResume(
      req.userId!,
      req.file
    );

    res.status(201).json({
      success: true,
      data: resume,
    });

  } catch (error) {

    console.error(error);

    res.status(500).json({
      success: false,
      message: "Resume processing failed",
    });

  }
};

export const getResumeHistory = async (
  req: AuthRequest,
  res: Response
) => {
  try {

    const resumes = await Resume.find({
      user: req.userId,
    })
      .sort({
        createdAt: -1,
      });

    res.json({
      success: true,
      data: resumes,
    });

  } catch (error) {

    console.error(error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch history",
    });

  }
};

export const getResumeById = async (
  req: AuthRequest,
  res: Response
) => {
  try {

    const resume = await Resume.findOne({
      _id: req.params.id,
      user: req.userId,
    });

    if (!resume) {
      return res.status(404).json({
        success: false,
        message: "Resume not found",
      });
    }

    res.json({
      success: true,
      data: resume,
    });

  } catch (error) {

    console.error(error);

    res.status(500).json({
      success: false,
      message: "Failed",
    });

  }
};

export const deleteResume = async (
  req: AuthRequest,
  res: Response
) => {
  try {

    const resume = await Resume.findOneAndDelete({
      _id: req.params.id,
      user: req.userId,
    });

    if (!resume) {
      return res.status(404).json({
        success: false,
        message: "Resume not found",
      });
    }

    res.json({
      success: true,
      message: "Resume deleted",
    });

  } catch (error) {

    console.error(error);

    res.status(500).json({
      success: false,
      message: "Delete failed",
    });

  }
};