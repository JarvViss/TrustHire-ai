import { Router } from "express";

import authRoutes from "./auth.routes";
import resumeRoutes from "./resume.routes";
import jobRoutes from "./job.routes";
import interviewRoutes from "./interview.routes";
import recruiterRoutes from "./recruiter.routes";

const router = Router();

router.use("/auth", authRoutes);

router.use("/resume", resumeRoutes);

router.use("/job", jobRoutes);

router.use("/interview", interviewRoutes);

router.use("/recruiter", recruiterRoutes);

export default router;