import { Router } from "express";

import { protect } from "../middleware/auth.middleware";

import {
  createInterview,
  answerInterview,
  getInterview,
} from "../controllers/interview.controller";

const router = Router();

router.post(
  "/start",
  protect,
  createInterview
);

router.post(
  "/answer",
  protect,
  answerInterview
);

router.get(
  "/:id",
  protect,
  getInterview
);

export default router;