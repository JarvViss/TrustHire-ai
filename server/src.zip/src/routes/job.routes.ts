import { Router } from "express";

import { protect } from "../middleware/auth.middleware";

import { analyzeJob } from "../controllers/job.controller";

const router = Router();

router.post(
  "/analyze",
  protect,
  analyzeJob
);

export default router;