import { Router } from "express";

import {
  getDashboardStats,
  getCandidates,
  getCandidateById,
} from "../controllers/recruiter.controller";

import { protect } from "../middleware/auth.middleware";
import { recruiterOnly } from "../middleware/recruiter.middleware";

const router = Router();

router.use(protect);
router.use(recruiterOnly);

// Dashboard
router.get("/dashboard", getDashboardStats);

// Candidate List
router.get("/candidates", getCandidates);

// Candidate Profile
router.get("/candidate/:id", getCandidateById);

export default router;