import { Router } from "express";

import { protect } from "../middleware/auth.middleware";

import { recruiterOnly } from "../middleware/recruiter.middleware";

import { recruiterAction } from "../controllers/recruiterAction.controller";

const router = Router();

router.use(protect);

router.use(recruiterOnly);

router.post(
  "/candidate/action",
  recruiterAction
);

export default router;