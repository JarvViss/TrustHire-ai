import { Router } from "express";

import upload from "../middleware/upload.middleware";

import { protect } from "../middleware/auth.middleware";

import {
  uploadResume,
  getResumeHistory,
  getResumeById,
  deleteResume,
} from "../controllers/resume.controller";

const router = Router();

router.post(
  "/upload",
  protect,
  upload.single("resume"),
  uploadResume
);

router.get(
  "/history",
  protect,
  getResumeHistory
);

router.get(
  "/:id",
  protect,
  getResumeById
);

router.delete(
  "/:id",
  protect,
  deleteResume
);

export default router;