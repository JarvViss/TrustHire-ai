import User from "../models/User";
import Resume from "../models/Resume";
import Interview from "../models/Interview";
import JobAnalysis from "../models/JobAnalysis";

export async function dashboardStats() {
  const totalCandidates = await User.countDocuments({
    role: "candidate",
  });

  const totalResumes =
    await Resume.countDocuments();

  const completedInterviews =
    await Interview.countDocuments({
      status: "COMPLETED",
    });

  const verifiedCandidates =
    await User.countDocuments({
      isVerified: true,
      role: "candidate",
    });

  return {
    totalCandidates,
    totalResumes,
    completedInterviews,
    verifiedCandidates,
  };
}

export async function candidateList() {
  const resumes = await Resume.find()
    .populate(
      "user",
      "name email profileImage headline isVerified"
    )
    .sort({
      createdAt: -1,
    });

  const candidates = await Promise.all(
    resumes.map(async (resume: any) => {
      const interview =
        await Interview.findOne({
          user: resume.user._id,
        }).sort({
          createdAt: -1,
        });

      const analysis =
        await JobAnalysis.findOne({
          user: resume.user._id,
        }).sort({
          createdAt: -1,
        });

      return {
        id: resume.user._id,

        name: resume.user.name,

        email: resume.user.email,

        profileImage:
          resume.user.profileImage,

        headline: resume.user.headline,

        verified:
          resume.user.isVerified,

        atsScore: resume.atsScore,

        interviewScore:
          interview?.result?.overall ?? 0,

        recommendation:
          interview?.result?.recommendation ??
          "Not Interviewed",

        jobMatch:
          analysis?.matchScore ?? 0,

        skills: resume.skills,
      };
    })
  );

  return candidates;
}




export async function getCandidateProfile(
  candidateId: string
) {
  const user = await User.findById(candidateId).select("-password");

  if (!user) {
    throw new Error("Candidate not found");
  }

  const resume = await Resume.findOne({
    user: candidateId,
  }).sort({
    createdAt: -1,
  });

  const interview = await Interview.findOne({
    user: candidateId,
  }).sort({
    createdAt: -1,
  });

  const analysis = await JobAnalysis.findOne({
    user: candidateId,
  }).sort({
    createdAt: -1,
  });

  return {
    user,
    resume,
    interview,
    analysis,
  };
}