import CandidateStatus from "../models/CandidateStatus";

export async function updateCandidateStatus(
  recruiter: string,
  candidate: string,
  status: string,
  notes: string
) {
  return CandidateStatus.findOneAndUpdate(
    {
      candidate,
    },
    {
      recruiter,
      candidate,
      status,
      notes,
    },
    {
      upsert: true,
      new: true,
    }
  );
}