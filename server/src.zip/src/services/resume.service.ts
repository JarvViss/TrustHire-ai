import Resume from "../models/Resume";
import { extractTextFromPDF } from "./pdf.service";
import { analyzeResume } from "./ai.service";

export const processResume = async (
  userId: string,
  file: Express.Multer.File
) => {

  const extractedText =
    await extractTextFromPDF(file.path);

  const analysis =
    await analyzeResume(extractedText);

  return await Resume.create({

    user: userId,

    filename: file.originalname,

    atsScore: analysis.atsScore,

    summary: analysis.summary,

    skills: analysis.skills,

    missingSkills: analysis.missingSkills,

    strengths: analysis.strengths,

    suggestions: analysis.suggestions,

  });

};

export const getUserResumes = async (
  userId: string
) => {

  return Resume.find({
    user: userId,
  }).sort({
    createdAt: -1,
  });

};